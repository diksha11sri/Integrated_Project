package com.cg.onlineMovieBookingSystem.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.onlineMovieBookingSystem.Entity.Ticket;


@Service
public interface TicketService {

    
	public List<Ticket> showTicket();
	public void cancelBookings(int ticketId);
	
	public void addTicket(Ticket ticket);
	

}